#parse("PHP Function Doc Comment.php")
public function __construct(${PARAM_LIST}) {${BODY}}