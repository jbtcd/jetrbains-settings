/**
${PARAM_DOC}
#if (${THROWS_DOC} != "")
*
${THROWS_DOC}
#end
#if (${TYPE_HINT} && ${TYPE_HINT} != "void") 
*
* @return ${TYPE_HINT}
#end
*/
