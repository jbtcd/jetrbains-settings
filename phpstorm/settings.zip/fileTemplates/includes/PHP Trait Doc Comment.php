/**
 * Trait ${NAME}
 */
